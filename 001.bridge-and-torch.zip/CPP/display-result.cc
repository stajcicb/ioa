#include "init.h"
#include "log.h"
#include "base.h"
#include "integer.h"
#include "string.h"
#include "array.h"
#include "table.h"
#include "display-result.h"

void displayResult(int* path){
  Array* columns = new Array();
  columns->push(new String("Cross the bridge"));
  columns->push(new String("Returns the torch"));

  Table* table = new Table(columns);
  int cost = 0;
  int i = 0;

  while(path[i] != -1 || path[i + 1] != -1){
    Array* row = new Array();
    Array* arr = new Array();

    while(path[i] != -1)
      arr->push(new Integer(path[i++]));

    bool last = path[i] == -1 && path[i + 1] == -1;
    Integer* ret = last ? new Integer(-1) : RC(arr->pop(), Integer*);

    int costRow = 0;
    for(int j = 0; j != arr->len(); j++){
      Integer* integer = RC(arr->d[j], Integer*);
      int time = integer->val;
      if(time > costRow) costRow = time;

      arr->d[j] = integer->toString();
      delete integer;
    }

    cost += costRow;
    if(!last) cost += ret->val;

    row->push(arr->join(" "))->push(last ? new String("-") : ret->toString());
    table->addRow(row);
    delete ret;

    if(last) break;
    i++;
  }

  Integer* costInt = new Integer(cost);
  String* str = new String();
  str->add("Minimal time: ")->add(costInt->toString())->
    add("\n\n")->add(table->toString());
  log(str);

  delete costInt;
  delete str;
  delete table;
}