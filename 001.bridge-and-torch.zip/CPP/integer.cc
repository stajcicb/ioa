#include "log.h"
#include "base.h"
#include "string.h"
#include "array.h"
#include "integer.h"

Integer::Integer(int val){
  this->val = val;
}

Integer::Integer(Integer* val){
  this->val = val->val;
}

Integer::~Integer(){}

String* Integer::intHex(int val, int bytes, B prefix){
  Array* digits = new Array();

  for(int i = 0; i != bytes; i++){
    String* dd = new String();
    
    for(int j = 0; j != 2; j++){
      int d = (val >> (1 - j << 2)) & 15;
      dd->add(d < 10 ? '0' + d : 'A' + d - 10);
    }

    digits->unshift(dd);
    val >>= 8;
  }

  String* str = new String(prefix ? "0x" : "");

  String* s = digits->join("");
  str->add(s);
  delete s;

  delete digits;
  return str;
}

String* Integer::hex(int bytes, B prefix){
  return intHex(val);
}

CC Integer::className(){
  return "Integer";
}

Base* Integer::clone(B deep){
  return new Integer(this);
}

String* Integer::toString(){
  if(val == 0) return new String("0");

  String* s = new String("");
  int v = val;

  v = ABS(v);

  while(v != 0){
    s->add('0' + v % 10);
    v /= 10;
  }

  if(val < 0) s->add('-');

  return s->reverse();
}