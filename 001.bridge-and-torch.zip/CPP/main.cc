#include "init.h"
#include "log.h"
#include "display-result.h"

#include <stdio.h>

#define E(msg) { \
  printf("ERROR: %s\n", msg); \
  return 1; }

#define EC(cond, msg) { \
  if(cond) E(msg); }

struct Frame{
  int* times;
  int* indices;
  int n, m, cost;
  bool first = 1;

  Frame(int n){
    times = new int[n];
    indices = new int[n];
  }
};

int main(){
  int nMain, mMain;
  int* timesMain;

  // Read input
  printf("Total number of people: ");
  scanf("%d", &nMain);
  EC(nMain < 0, "Number of people cannot be negative");
  printf("Bridge capacity: ");
  scanf("%d", &mMain);
  EC(mMain < 0, "Bridge capacity cannot be negative");
  if(nMain != 0){
    printf("Time for each person: ");
    timesMain = new int[nMain];
    for(int i = 0; i != nMain; i++){
      int time;
      scanf("%d", &time);
      EC(time < 0, "Time cannot be negative");
      timesMain[i] = time;
    }
  }
  printf("\n");

  // Edge cases
  if(nMain == 0){
    int* r = new int[2]{-1, -1};
    displayResult(r);
    delete[] r;
    return 0;
  }
  if(mMain <= 1){
    if(nMain == 1 && mMain == 1){
      int* r = new int[3]{timesMain[0], -1, -1};
      displayResult(r);
      delete[] r;
      return 0;
    }
    printf("No solution exists\n");
    return 0;
  }

  // Sort the input array
  for(int i = 0; i != nMain; i++){
    for(int j = i + 1; j != nMain; j++){
      if(timesMain[j] < timesMain[i]){
        int t = timesMain[i];
        timesMain[i] = timesMain[j];
        timesMain[j] = t;
      }
    }
  }
  
  // Initialize virtual stack
  Frame** stack = new Frame*[nMain];
  for(int i = 0; i != nMain; i++)
    stack[i] = new Frame(nMain);

  // Populate the first stack frame
  Frame* frame = stack[0];
  frame->n = nMain;
  frame->m = MIN(nMain, 2);
  frame->cost = 0;
  for(int i = 0; i != nMain; i++)
    frame->times[i] = timesMain[i];

  int maxPathLen = nMain * 3 + 10;
  int* path = new int[maxPathLen];

  int costBest = -1;
  int frameIndex = 0;

  // Main loop
  while(frameIndex != -1){
    Frame* frame = stack[frameIndex];
    int* times = frame->times;
    int* indices = frame->indices;
    int n = frame->n;
    int m = frame->m;
    int cost = frame->cost;

    bool next = 0;

    if(frame->first)
      for(int i = 0; i != m; i++)
        indices[i] = m - i - 1;

    while(1){
      // Combination generator
      if(!frame->first){
        if(++indices[0] >= n){
          int i = 0;
          for(;indices[i] >= n - i - 1;) if(++i >= m) { next = 1; break; };
          if(i >= m) { next = 1; break; };
          for(++indices[i]; i; i--) indices[i - 1] = indices[i] + 1;
        }
      }
      frame->first = 0;

      int costNew = 0;
      for(int i = 0; i != m; i++){
        int time = times[indices[i]];
        if(time > costNew) costNew = time;
      }
      costNew += cost;

      // If the cost is already larger than the best cost,
      // stop expanding this branch
      if(costBest != -1 && costNew >= costBest) continue;

      if(m != n){ // Not the last iteration
        Frame* frameNew = stack[frameIndex + 1];
        int* timesNew = frameNew->times;
        int* indicesNew = frameNew->indices;

        int nNew = n - m + 1;
        int mNew = MIN(nNew, 2);

        int iMain = 0, j = m - 1, k = 0;
        for(int i = 0; i != n; i++){
          if(j == -1 || indices[j] != i){
            int time = times[i];
            if(iMain != -1){
              if(time == timesMain[iMain]){
                iMain++;
              }else{
                costNew += timesNew[k++] = timesMain[iMain];
                indices[m] = iMain;
                iMain = -1;
              }
            }
            timesNew[k++] = time;
          }else{
            j--;
          }
        }

        if(iMain != -1){
          costNew += timesNew[k++] = timesMain[iMain];
          indices[m] = iMain;
        }

        if(costBest != -1 && costNew >= costBest) continue;

        frameNew->n = nNew;
        frameNew->m = mNew;
        frameNew->cost = costNew;
        frameNew->first = 1;

        frameIndex++;
      }else{ // The last iteration
        if(costBest == -1 || costNew < costBest){
          costBest = costNew;
          int pathIndex = 0;

          for(int index = 0; index <= frameIndex; index++){
            Frame* frame = stack[index];
            int* times = frame->times;
            int* indices = frame->indices;
            int m = frame->m;

            for(int i = m - 1; i != -1; i--)
              path[pathIndex++] = times[indices[i]];

            if(index != frameIndex)
              path[pathIndex++] = timesMain[indices[m]];

            path[pathIndex++] = -1;
          }

          path[pathIndex] = -1;
        }

        frameIndex--;
      }

      break;
    }

    if(next){
      if(m != MIN(mMain, n)){
        m = ++frame->m;
        frame->first = 1;
      }else{
        frameIndex--;
      }
    }
  }

  // Display the result
  displayResult(path);

  // Cleanup
  delete[] path;
  delete[] stack;
  delete[] timesMain;

  return 0;
}