#pragma once

void displayResult(int* data);