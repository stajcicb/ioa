#pragma once

#include "init.h"

class Base;
class String;

void log();
char log(char a, int newLine=1);
int log(int a, int newLine=1);
const char* log(const char* a, int newLine=1);
char* log(char* a, int newLine=1);
String* log(String* a, int newLine=1);
Base* log(Base* a, int newLine=1);