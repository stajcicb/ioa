#pragma once

#include "init.h"
#include "base.h"

class String;
class Array;

class Table: public Base{
private:
  String* str;
  int* lens;

  int flag;
  char c1;
  char c2;

  String* fit(int len, String* str=nullptr, String* ch=nullptr);
  void apply(String* s, int type, Base* c1, String* c2, int f=-1);
  void applyArr(Array* arr);
  void setFlag(int f);
  char getCh(char ch, int f=-1);

public:
  int w;
  int h;

  Array* columns;
  Array* rows;

  Table(Array* columns);
  ~Table();

  Table* addRow(Array* row);

  virtual CC className();
  virtual Base* clone(B deep=1);
  virtual String* toString();
};