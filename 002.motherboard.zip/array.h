#pragma once

#include "init.h"
#include "base.h"

class String;

class Array: public Base{
private:
  int size;
  int length;

public:
  Base** d;

  Array();
  Array(Base* val);
  ~Array();

  int len();
  void len(int len);

  Array* unshift(Base* val);
  Array* unshift(const char* str);
  Array* push(Base* val);
  Array* push(const char* str);
  Base* shift();
  Base* pop();

  Base* first();
  Base* last();
  String* join(CC str=",");

  Array* expand();
  Array* unref();

  CC className();
  virtual Base* clone(B deep=1);
  virtual B isArray();
  virtual String* toString();
};