#pragma once

#include "init.h"
#include "base.h"

class String;

class Integer : public Base{
public:
  int val;

  Integer(int val=0);
  Integer(Integer* val);
  ~Integer();

  static String* intHex(int val, int bytes=2, B prefix=1);

  String* hex(int bytes=2, B prefix=1);

  virtual const char* className();
  virtual Base* clone(B deep=1);
  virtual String* toString();
};