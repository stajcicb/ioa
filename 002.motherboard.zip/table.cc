#include "log.h"
#include "base.h"
#include "integer.h"
#include "string.h"
#include "array.h"
#include "table.h"

Table::Table(Array* columns){
  this->columns = columns;
  this->rows = new Array();

  w = columns->len();
  h = 0;
}

Table::~Table(){
  delete columns;
  delete rows;

  columns = N;
  rows = N;

  str = N;
  lens = N;
}

Table* Table::addRow(Array* row){
  rows->push(row);
  h++;
  return this;
}

String* Table::fit(int len, String* str, String* ch){
  B wasNull = ch == N;
  if(wasNull) ch = new String(' ');

  if(str == N){
    String* s = CL(ch, String)->repeat(len);
    if(wasNull) delete ch;
    return s;
  }

  int strLen = str->len();
  int start = len - strLen >> 1;

  String* s = CL(ch, String)->repeat(start)->add(str)->padEnd(len, ch->fst());
  if(wasNull) delete ch;
  return s;
}

void Table::apply(String* s, int type, Base* c1, String* c2, int f){
  if(f == -1) f = flag;

  Array* arr = c1->isArray() ? RC(c1, Array*) : N;
  if(arr != N) c1 = N;

  str->add(s);

  for(int i = 0; i != w; i++){
    int len = lens[i];

    String* fstr = fit(
      len - (type && f && i == w - 1 ? 1 : 0),
      arr != N ? RC(arr->d[i], String*) : N,
      RC(c1, String*)
    );

    str->add(fstr)->add(c2);
    delete fstr;
  }
}

void Table::applyArr(Array* arr){
  Base** d = arr->d;
  int len = arr->len();
  int i = 0;

  while(i != len){
    String* arg1 = RC(d[i], String*);
    int arg2 = RC(d[i + 1], Integer*)->val;
    Base* arg3 = d[i + 2];
    String* arg4 = RC(d[i + 3], String*);

    if(len - i == 5){
      int arg5 = RC(d[i + 4], Integer*)->val;
      apply(arg1, arg2, arg3, arg4, arg5);
      i += 5;
    }else{
      apply(arg1, arg2, arg3, arg4);
      i += 4;
    }
  }
}

void Table::setFlag(int f){
  flag = f;
  c1 = getCh('+');
  c2 = getCh('-');
}

char Table::getCh(char ch, int f){
  if(f == -1) f = flag;
  return f ? ch : '|';
}

CC Table::className(){
  return "Table";
}

Base* Table::clone(B deep){
  Table* table = new Table(deep ? CL(columns, Array) : columns);

  delete table->rows;
  table->rows = deep ? CL(rows, Array) : rows;
  table->h = h;

  return table;
}

String* Table::toString(){
  str = new String();
  lens = new int[w];

  for(int i = 0; i != w; i++)
    lens[i] = RC(columns->d[i], String*)->len();

  for(int i = 0; i != h; i++){
    Array* row = RC(rows->d[i], Array*);
    for(int j = 0; j != w; j++)
      lens[j] = MAX(lens[j], RC(row->d[j], String*)->len());
  }

  for(int i = 0; i != w; i++)
    lens[i] += 2;

  setFlag(1);
  char c = getCh('+', h == 0);

  Array* arr = (new Array())->
    push(new String("+"))->push(new Integer(1))->push(new String("-"))->push(new String("-"))->
    push(new String("+\n|"))->push(new Integer(0))->push(new String(" "))->push(new String("|"))->
    push(new String("\n|"))->push(new Integer(0))->push(CL(columns, Array))->push(new String("|"))->
    push(new String("\n|"))->push(new Integer(0))->push(new String(" "))->push(new String("|"))->
    push((new String("\n"))->add(c))->push(new Integer(1))->push(new String("="))->push(new String("="))->push(new Integer(1));
  applyArr(arr);
  delete arr;

  str->add(c);

  for(int i = 0; i != h; i++){
    Array* row = RC(rows->d[i], Array*);
    setFlag(i == h - 1);

    Array* arr = (new Array())->
      push(new String("\n|"))->push(new Integer(0))->push(new String(" "))->push(new String("|"))->
      push(new String("\n|"))->push(new Integer(0))->push(CL(row, Array))->push(new String("|"))->
      push(new String("\n|"))->push(new Integer(0))->push(new String(" "))->push(new String("|"))->
      push((new String("\n"))->add(c1))->push(new Integer(1))->push(new String("-"))->push(new String(c2));
    applyArr(arr);
    delete arr;

    if(flag) str->add(c1);
  }

  delete[] lens;
  return str;
}