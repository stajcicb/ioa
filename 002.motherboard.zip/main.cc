#include "init.h"
#include "log.h"
#include "display-result.h"

#include <stdio.h>
#include <math.h>

// Solution:
//   Path: (4,6,9,10,11,13,15,18,20,19,17,16,14,8,7,5,1,2,3,12)
//   Cost: 205.126333

#define E(msg) { \
  printf("ERROR: %s\n", msg); \
  return 1; }

#define EC(cond, msg) { \
  if(cond) E(msg); }

struct Frame{
  double cost = 0;
  int index = -1;
  int visited = 0;
};

bool side(double x1, double y1, double x2, double y2, double x3, double y3){
  return (y3 - y1) * (x2 - x1) < (x3 - x1) * (y2 - y1);
}

bool oppositeSide(double x1, double y1, double x2, double y2, double x3, double y3, double x4, double y4){
  return side(x1, y1, x2, y2, x3, y3) != side(x1, y1, x2, y2, x4, y4);
}

bool intersects(double x1, double y1, double x2, double y2, double x3, double y3, double x4, double y4){
  return oppositeSide(x1, y1, x2, y2, x3, y3, x4, y4) & oppositeSide(x3, y3, x4, y4, x1, y1, x2, y2);
}

int main(){
  int n = 20;

  double coords[40]{
    62.0, 58.4, // 1
    57.5, 56.0, // 2
    51.7, 56.0, // 3
    67.9, 19.6, // 4
    57.7, 42.1, // 5
    54.2, 29.1, // 6
    46.0, 45.1, // 7
    34.7, 45.1, // 8
    45.7, 25.1, // 9
    34.7, 26.4, // 10
    28.4, 31.7, // 11
    33.4, 60.5, // 12
    22.9, 32.7, // 13
    21.5, 45.8, // 14
    15.3, 37.8, // 15
    15.1, 49.6, // 16
     9.1, 52.8, // 17
     9.1, 40.3, // 18
     2.7, 56.8, // 19
     2.7, 33.1, // 20
  };

  double** dists = new double*[n];
  for(int i = 0; i != n; i++){
    double* d = dists[i] = new double[n];
    for(int j = 0; j != n; j++){
      double dx = coords[i * 2] - coords[j * 2];
      double dy = coords[i * 2 + 1] - coords[j * 2 + 1];
      d[j] = sqrt(dx * dx + dy * dy);
    }
  }

  bool**** lines = new bool***[n];
  for(int a = 0; a != n; a++){
    bool*** d1 = lines[a] = new bool**[n];
    for(int b = 0; b != n; b++){
      bool** d2 = d1[b] = new bool*[n];
      for(int c = 0; c != n; c++){
        bool* d3 = d2[c] = new bool[n];
        for(int d = 0; d != n; d++){
          d3[d] = d3[d] = intersects(
            coords[a * 2], coords[a * 2 + 1],
            coords[b * 2], coords[b * 2 + 1],
            coords[c * 2], coords[c * 2 + 1],
            coords[d * 2], coords[d * 2 + 1]
          );
        }
      }
    }
  }

  Frame** stack = new Frame*[n];
  for(int i = 0; i != n; i++) stack[i] = new Frame();

  int* pathBest = new int[n];
  double costBest = F;

  int* path = new int[n];
  int frameIndex = 0;
  int z = 0;

  while(frameIndex != -1){
    Frame* frame = stack[frameIndex];
    double& cost = frame->cost;
    int& index = frame->index;
    int& visited = frame->visited;

    if(frameIndex >= 4 && ++z == (int)1e8){
      z = 0;

      double min =  3 + 20 * ( 2 + 20 * ( 1 + 20 *  0));
      double max = 17 + 20 * (18 + 20 * (19 + 20 * 20));
      double cur = path[3] + 20 * (path[2] + 20 * (path[1] + 20 * path[0]));

      printf("Curent:  ");
      for(int i = 0; i != n; i++) log(i < frameIndex ? (char)('A' + path[i]) : ' ', 0), log(" ", 0);
      printf(" ---> %c%lf\n", ' ', cost);
      printf("Best:    ");
      for(int i = 0; i != n; i++) log((char)('A' + pathBest[i]), 0), log(" ", 0);
      printf(" --->  %lf\n", costBest);
      printf("Percent: %lf\n\n", (cur - min) / (max - min) * 100);
    }

    while(index != n){
      if(visited & (1 << ++index)) continue;
      if(index == n) break;
      if(frameIndex <= 2) break;

      bool** line = lines[path[frameIndex - 1]][index];
      bool found = 0;

      for(int i = frameIndex - 2; i != 0; i--){
        if(line[path[i - 1]][path[i]]){
          found = 1;
          break;
        }
      }

      if(found) continue;
      break;
    }

    if(index == n){
      frameIndex--;
      continue;
    }

    path[frameIndex] = index;

    double costNew = cost;
    if(frameIndex != 0) costNew += dists[path[frameIndex - 1]][index];
    if(costNew >= costBest) continue;

    if(frameIndex == n - 1){
      if(costNew < costBest){
        costBest = costNew;
        for(int i = 0; i != n; i++)
          pathBest[i] = path[i];
      }
      continue;
    }

    Frame* frameNew = stack[++frameIndex];
    frameNew->cost = costNew;
    frameNew->index = -1;
    frameNew->visited = visited | (1 << index);
  }

  log("\n=============================\n");
  printf("%lf\n", costBest);
  for(int i = 0; i != n; i++) log((char)('A' + pathBest[i]), 0), log(" ", 0);
  log();

  return 0;
}