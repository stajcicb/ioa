'use strict';

const fs = require('fs');
const path = require('path');
const O = require('../omikron');
const Rational = require('../rational');

const NUM = 10;

class Check{
  #mat;
  #err;
  #nums = O.obj();

  constructor(mat, err){
    this.#mat = mat;
    this.#err = err;
  }

  check(){
    const mat = this.#mat;
    const nums = this.#nums;

    const num = mat.get(mat.w - 1, 0);
    const {a, b} = num;

    if(!(a in nums)) nums[a] = O.obj();
    if(!(b in nums[a])) nums[a][b] = 0;

    if(++nums[a][b] === NUM)
      this.fail();
  }

  fail(){
    this.#err('Unable to solve the system');
  }
}

module.exports = Check;