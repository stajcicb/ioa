'use strict';

const fs = require('fs');
const path = require('path');
const O = require('../omikron');
const config = require('../config');
const matrices = require('../matrices');
const Rational = require('../rational');
const debug = require('../debug');
const Check = require('./check');

const {min, max, floor, ceil, round} = Math;

const DISPLAY_MATRIX = 0;

const cwd = __dirname;
const modelFile = path.join(cwd, config.modelFile);

const main = () => {
  const mat = matrices.convertToMatrix(O.rfs(modelFile));
  if(!mat) return;

  const {target, idents} = mat;
  const {varsNum} = mat;
  const indices = O.obj();

  {
    const {w, h} = mat;

    for(let y = 1; y !== h; y++){
      let div = 1n;

      for(let x = 0; x !== w; x++){
        let {b} = mat.get(x, y);
        if(b > div) div = b;
      }

      const r = new Rational(div);

      for(let x = 0; x !== w; x++){
        if(x >= varsNum && x !== w - 1) continue;
        mat.get(x, y).mul(r);
      }
    }
  }

  const logs = [];

  const err = msg => {
    for(const str of logs) log(str);
    O.exit(`ERROR: ${msg}`);
  };

  const check = new Check(mat, err);

  const logMat = (mode=0) => {
    if(!DISPLAY_MATRIX) return;

    if(mode === 1) logs.push(`\n${'='.repeat(100)}\n`);

    logs.push(`\n${mat}\n`);

    if(mode === 2){
      for(const str of logs) log(str);
      debug();
    }
  };

  const reduce = (x, updateRows=1) => {
    check.check();

    const {w, h} = mat;
    const val = new Rational();
    let ymin = -1;

    for(let y = 1; y !== h; y++){
      const a = mat.get(x, y);
      if(a.eq(Rational.ZERO)) continue;

      const b = mat.get(w - 1, y);
      if(a.lt(Rational.ZERO) && b.gt(Rational.ZERO)) continue;

      const c = b.slice().div(a);

      if(ymin === -1 || c.lt(val)){
        val.set(c);
        ymin = y;
      }
    }

    if(ymin === -1){
      const msg = x < varsNum ?
        `Variable ${O.sf(idents[x])} does` :
        `Some of the variables do`;

      err(`${msg} not have valid constraints`);
    }

    indices[x] = ymin;

    for(let y = 0; y !== h; y++){
      if(y === ymin){
        const a = mat.get(x, y).slice();

        for(let x = 0; x !== w; x++)
          mat.div(x, y, a);

        continue;
      }

      if(!updateRows) continue;

      const a = mat.get(x, y).slice().div(mat.get(x, ymin));

      for(let x = 0; x !== w; x++)
        mat.sub(x, y, mat.get(x, ymin).slice().mul(a));
    }
  };

  const reduced = O.obj();

  while(1){
    logMat();

    const {w, h} = mat;
    let found = 0;

    while(1){
      const val = new Rational();
      let xmin = -1;

      for(let x = 0; x !== w - 1; x++){
        const a = mat.get(x, 0);
        if(a.gte(Rational.ZERO)) continue;

        if(xmin === -1 || a.lt(val)){
          val.set(a);
          xmin = x;
        }
      }

      if(xmin === -1) break;

      found = 1;

      // log(mat+'\n')
      // log('[1] REDUCE', xmin, '\n');
      reduce(xmin);
      // debug(mat+'\n');
      // log('\n\n\n\n=================\n\n\n\n')
      
      logMat(1);
    }

    while(1){
      const {w, h} = mat;
      
      const val = new Rational();
      let ymin = -1;

      for(let y = 0; y !== h; y++){
        const a = mat.get(w - 1, y);
        if(a.isInt) continue;

        const b = a.slice().frac();
        if(b.eq(Rational.ZERO)) continue;

        if(ymin === -1 || b.gt(val)){
          val.set(b);
          ymin = y;
        }
      }

      if(ymin === -1) break;

      found = 1;

      {
        logMat(1);

        const {w, h} = mat.expand();

        for(let x = 0; x !== w; x++)
          mat.set(x, h - 1, mat.get(x, ymin).slice().frac().neg());

        mat.set(w - 2, h - 1, Rational.ONE);

        logMat(2);

        const val = new Rational();
        let xmin = -1;

        for(let i = 0; i !== 2; i++){
          for(let x = varsNum; x !== w - 2; x++){
            if(i === 0 && x in reduced) continue;

            const a = mat.get(x, 0);
            if(a.eq(Rational.ZERO)) continue;

            if(xmin === -1 || a.lt(val)){
              val.set(a);
              xmin = x;
            }
          }

          if(xmin !== -1) break;
        }

        // log(mat+'\n')
        // log('[2] REDUCE', xmin, '\n');
        reduce(xmin);
        // debug(mat+'\n');
        // log('\n\n\n\n=================\n\n\n\n')

        reduced[xmin] = 1;

        let neg = 0;
        for(let x = 0; x !== w; x++)
          if(mat.get(x, 0).lt(Rational.ZERO))
            neg = 1;
        if(neg) break;
      }
    }

    if(!found) break;
  }

  logMat(1);
  for(const str of logs) log(str);

  {
    const {w, h} = mat;
    const logs = [];

    let found = 1;

    const val = mat.get(w - 1, 0);
    if(val.lt(Rational.ZERO)) found = 0;
    logs.push(`${target} = ${val.toFloat()}\n`);

    for(let x = 0; x !== varsNum; x++){
      let isNonZero = 1;

      for(let y = 1; y !== h; y++)
        if(mat.get(x, y).lt(Rational.ZERO))
          isNonZero = 0;

      const val = isNonZero && x in indices && mat.get(x, 0).eq(Rational.ZERO) ?
        mat.get(w - 1, indices[x]) : Rational.ZERO;

      if(val.lt(Rational.ZERO)) found = 0;
      logs.push(`${mat.idents[x]} = ${val.toFloat()}`);
    }

    if(found){
      for(const str of logs) log(str);
    }else{
      check.fail();
    }
  }
};

main();