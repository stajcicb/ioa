'use strict';

const O = require('../deps/omikron');

module.exports = O;