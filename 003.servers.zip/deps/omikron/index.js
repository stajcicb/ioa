'use strict';

const O = require('./omikron');;

module.exports = O;