'use strict';

const fs = require('fs');
const path = require('path');
const O = require('../deps/omikron');
const list = require('./list');

const langsObj = O.obj();
const langsIdsObj = O.obj();

for(const info of list){
  langsObj[info.name] = info;
  langsIdsObj[info.id] = info;
}

const cwd = __dirname;
const langsDir = path.join(cwd, 'src');

const mats = {
  convertToMatrix(str){
    const empty = '';
    return mats.run(empty, str, empty);
  },

  getLangs(){
    return list.map(a => a.name);
  },

  getInfo(name){
    if(!(name in langsObj)) return null;
    return langsObj[name];
  },

  getInfoById(id){
    if(!(id in langsIdsObj)) return null;
    return langsIdsObj[id];
  },

  run(name, src, input){
    const info = mats.getInfo(name);
    if(info === null) throw new TypeError(`Unsupported language ${O.sf(name)}`);

    const func = require(path.join(langsDir, info.id));
    const output = func(Buffer.from(src), Buffer.from(input));

    return output;
  },

  getStrs(){
    return commonStrs.names.slice();
  },

  getStr(name){
    const {strs} = commonStrs;
    if(!(name in strs)) return null;
    return strs[name];
  },
};

module.exports = mats;