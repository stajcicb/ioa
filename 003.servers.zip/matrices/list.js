'use strict';

const list = [{
  "name": "",
  "id": "matrices",
  "version": "1.0.0",
  "details": ""
}];

module.exports = list;