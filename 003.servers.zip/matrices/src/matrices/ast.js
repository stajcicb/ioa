'use strict';

const fs = require('fs');
const path = require('path');
const O = require('../../../deps/omikron');
const Rational = require('../../../rational');
const cs = require('./ctors');

const rules = {
  script: e => new cs.Model(e.es[1].fst, e.es[3].arr),
  target: e => new cs.Target(e.es[0].fst, e.es[4].fst),
  constraint: e => new cs.Constraint(e.es[0].fst, e.es[4].fst),
  constraintSep: e => e.fst.fst,
  expr: e => new cs.Expression(e.fst.arr, e.fst.seps),
  elem: e => {
    if(e.pti == 0) return new cs.Element(e.es[0].arr, e.es[2].fst);
    else return new cs.Element(e.es[4].arr, e.fst.fst);
  },
  elemSep: e => e.fst.fst,
  factor: e => e.fst.fst,
  mul: e => e.fst.fst,
  ident: e => String(e),

  num: e => {
    let str = String(e);
    let pos = 1;

    if(str.startsWith('+'))
      str = str.slice(1);

    if(str.startsWith('-')){
      pos = 0;
      str = str.slice(1);
    }

    const parts = str.split('.');
    const p1 = parts[0];
    const p2 = parts.length === 2 ? parts[1] : '';

    const digits = p1 + p2 || '1';
    const a = BigInt(digits) * (pos ? 1n : -1n);
    const b = 10n ** BigInt(p2.length);

    const r = new Rational(a, b);

    return r;
  },

  numBase: e => e.fst.fst,
  num1: e => e.fst.fst,
  num2: e => e.fst.fst,
  decimals: e => e.fst.fst,
  whitespace: e => e.fst.fst,
  comment: e => e.fst.fst,
  inlineComment: e => e.fst.fst,
  multilineComment: e => e.fst.fst,
  s: e => e.fst.fst,
  s0: e => e.fst.fst,
  s1: e => e.fst.fst,
  n: e => e.fst.fst,
};

module.exports = rules;