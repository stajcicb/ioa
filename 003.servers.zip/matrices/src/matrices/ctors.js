'use strict';

const fs = require('fs');
const path = require('path');
const O = require('../../../deps/omikron');
const Rational = require('../../../rational');

class Base{}

class Model extends Base{
  constructor(target, constraints){
    super();

    if(constraints.length === 0)
      O.exit('ERROR: Expected at least one constraint');

    this.target = target;
    this.constraints = constraints;
  }
}

class Target extends Base{
  constructor(ident, expr){
    super();
    this.ident = ident;
    this.expr = expr;
  }
}

class Constraint extends Base{
  constructor(expr, num){
    super();
    this.expr = expr;
    this.num = num;
  }
}

class Expression extends Base{
  constructor(elems, seps){
    super();

    this.elems = elems;

    seps.forEach((sep, index) => {
      if(String(sep).includes('-'))
        elems[index + 1].factor.neg();
    });
  }
}

class Element extends Base{
  constructor(factor, ident){
    super();
    this.factor = factor.length !== 0 ? factor[0] : Rational.ONE.slice();
    this.ident = ident;
  }
}

module.exports = {
  Base,
  Model,
  Target,
  Constraint,
  Expression,
  Element,
};