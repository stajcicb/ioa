'use strict';

const fs = require('fs');
const path = require('path');
const O = require('../../../deps/omikron');
const Rational = require('../../../rational');
const cs = require('./ctors');
const Matrix = require('./matrix');

class Engine{
  constructor(parsed, input){
    this.system = parsed;
    this.matrix = null;
  }

  run(){
    const {system} = this;
    const {target, constraints} = system;

    const exprs = [];
    const identsSet = new Set([target.ident]);

    const addIdents = expr => {
      exprs.push(expr);

      for(const elem of expr.elems)
        identsSet.add(elem.ident)
    };

    addIdents(target.expr);

    for(const ct of constraints)
      addIdents(ct.expr);

    const identsArr = [...identsSet];
    const identsMap = new Map();

    for(let i = 0; i !== identsArr.length; i++)
      identsMap.set(identsArr[i], i);

    const w = identsArr.length + constraints.length;
    const h = constraints.length + 1;

    const mat = new Matrix(w, h, identsArr.slice());

    exprs.forEach((expr, y) => {
      const idents = O.obj();

      for(const elem of expr.elems){
        let {factor} = elem;
        if(y === 0) factor.neg();

        const {ident} = elem;

        if(ident in idents)
          O.exit(`ERROR: Variable ${O.sf(ident)} cannot appear more than once in a single expression`);

        idents[ident] = 1;

        const identIndex = identsMap.get(ident);

        if(identIndex === 0)
          O.exit(`ERROR: Target variable ${O.sf(ident)} cannot appear in other expressions`);

        mat.set(identIndex - 1, y, factor);
      }

      if(y !== 0){
        mat.set(w - constraints.length + y - 2, y, Rational.ONE.slice());
        mat.set(w - 1, y, constraints[y - 1].num);
      }
    });

    this.matrix = mat;
  }
  
  getOutput(){
    return this.matrix;
  }
}

module.exports = Engine;